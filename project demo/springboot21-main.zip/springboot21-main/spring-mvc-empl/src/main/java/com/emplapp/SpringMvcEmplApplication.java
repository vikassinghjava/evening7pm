package com.emplapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcEmplApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcEmplApplication.class, args);
	}

}
