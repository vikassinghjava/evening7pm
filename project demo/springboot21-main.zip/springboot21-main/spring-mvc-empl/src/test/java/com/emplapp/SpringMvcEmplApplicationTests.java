package com.emplapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcEmplApplicationTests {

	@Test
	void contextLoads() {
	}

}
