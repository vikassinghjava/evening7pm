package com.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcBasicApplication.class, args);
	}

}
