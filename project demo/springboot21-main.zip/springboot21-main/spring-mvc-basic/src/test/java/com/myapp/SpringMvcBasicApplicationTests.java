package com.myapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMvcBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
