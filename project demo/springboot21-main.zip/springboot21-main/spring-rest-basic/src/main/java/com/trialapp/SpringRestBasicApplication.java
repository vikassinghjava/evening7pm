package com.trialapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestBasicApplication.class, args);
	}

}
