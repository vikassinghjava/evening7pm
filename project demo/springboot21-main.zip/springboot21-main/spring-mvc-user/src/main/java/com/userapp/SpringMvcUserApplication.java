package com.userapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMvcUserApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMvcUserApplication.class, args);
	}

}
