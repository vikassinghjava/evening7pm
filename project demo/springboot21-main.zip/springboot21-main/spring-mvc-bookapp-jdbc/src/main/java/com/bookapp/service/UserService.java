package com.bookapp.service;

import com.bookapp.model.User;

public interface UserService {
	String validateUser(User user);

}
