package com.mobapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestMobclientApplicationTests {

	@Test
	void contextLoads() {
	}

}
