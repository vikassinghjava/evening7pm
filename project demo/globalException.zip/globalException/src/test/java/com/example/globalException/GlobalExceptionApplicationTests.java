package com.example.globalException;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalExceptionApplicationTests {

	@Test
	void contextLoads() {
	}

}
